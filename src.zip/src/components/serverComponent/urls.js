export const PYTHON_URL= 'http://35.188.231.22:8000/'
export const PHP_FORM= 'http://34.138.222.96/formulario_atlantico/indexForm.php?'