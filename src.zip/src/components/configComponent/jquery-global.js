import $ from "jquery";
globalThis.jQuery = $;