//

export const User = sessionStorage.getItem('User-juan-de-acosta');
export const logo_map='./assets/icons/logos/logo-small.png';
export const title_sidebar='Modelo Extendido';
export const title_sidebar_sm='SUI';
export const dependence_id = 3;


