import $ from "jquery";
// psv en Español
export var psvLanguage=()=>{
    // $('.psv-autorotate-button').eq(0).prop('title', 'Rotación automática');
    // $('.psv-zoom-button').eq(0).prop('title', 'Alejar');
    // $('.psv-zoom-button').eq(1).prop('title', 'Acercar');
    // $('.psv-download-button').eq(0).prop('title', 'Descargar');
    // $('.psv-fullscreen-button').eq(0).prop('title', 'Activar o desactivar la vista de pantalla completa');    
    $('.psv-caption-button').eq(0).prop('title', 'Fecha');
}
