import './capture.scss';

import './controls/sliceMap360'
