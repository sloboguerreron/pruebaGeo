// POINT STYLE

export var point_style= (pcolor) => {
	return {
		opacity: 0,
		fillColor: pcolor,
		fillOpacity: 0.5,
		color: pcolor,
        width: 3
	};
};