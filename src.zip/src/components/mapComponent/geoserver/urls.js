export const GEOSERVER_URL='http://34.132.27.64:8080/geoserver/'
// export const GEOSERVER_URL='http://34.86.14.180:8080/geoserver/'
export const GEOSERVER_STORE= 'yopal'
