import 'bootstrap';

import './components/mapComponent/map-control';

import './components/pageComponent/side-bar/side-bar';
import './components/pageComponent/split-views';
// import './components/configComponent/update-vars';

